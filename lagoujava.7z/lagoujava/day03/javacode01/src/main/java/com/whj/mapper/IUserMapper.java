package com.whj.mapper;

import com.whj.pojo.Order;

public interface IUserMapper {
    //查询订单的同时，查询该订单所属的用户
    Order findOrderAndUser();
}

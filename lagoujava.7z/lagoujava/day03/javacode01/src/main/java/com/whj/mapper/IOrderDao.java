package com.whj.mapper;

import com.whj.pojo.Order;

public interface IOrderDao {
    void insertOrder(Order order);
}

package com.whj.test;

import com.whj.io.Resources;

import java.io.InputStream;

/**
 * 测试方法
 */
public class IpersistenceTest {
    public void test(){
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
    }
}

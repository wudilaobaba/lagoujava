package com.whj.test;

import com.whj.io.Resources;
import com.whj.pojo.User;
import com.whj.sqlSession.SqlSession;
import com.whj.sqlSession.SqlSessionFactory;
import com.whj.sqlSession.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * 测试方法
 */
public class IpersistenceTest {
    @Test
    public void test() throws Exception {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(2);
        user.setUsername("张安");
        User user2 = sqlSession.selectOne("user.selectOne", user);

        List<User> userList = sqlSession.selectList("user.selectList",user);
    }
}

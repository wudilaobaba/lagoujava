package com.whj.sqlSession;

public interface SqlSessionFactory {
    SqlSession openSession();
}

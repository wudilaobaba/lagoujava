package com.whj.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.whj.io.Resources;
import com.whj.pojo.Configuration;
import com.whj.pojo.MappedStatement;
import lombok.Getter;
import lombok.Setter;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

@Getter
@Setter
public class XMLConfigBuilder {
    private Configuration configuration;
    private MappedStatement mappedStatement;
    public XMLConfigBuilder(){
        this.configuration = new Configuration();
        this.mappedStatement = new MappedStatement();
    }
    /**
     * 该方法就是使用dom4j将配置文件进行解析，封装Configuration
     */
    public Configuration parseConfig(InputStream in) throws Exception {
        //解析 sqlMapperConfig.xml
        Document document = new SAXReader().read(in);
        Element rootElement = document.getRootElement();//<configuration>
        List<Element> list = rootElement.selectNodes("//property");//所有<property>
        Properties properties = new Properties();
        for (Element element : list) {
            String name = element.attributeValue("name");
            String value = element.attributeValue("value");
            properties.setProperty(name,value);
        }
        //设置数据库连接池
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
        comboPooledDataSource.setDriverClass(properties.get("driverClass").toString());
        comboPooledDataSource.setJdbcUrl(properties.get("jdbcUrl").toString());
        comboPooledDataSource.setUser(properties.get("userName").toString());
        comboPooledDataSource.setPassword(properties.get("password").toString());

        this.configuration.setDataSource(comboPooledDataSource);


        //解析 xxxMapper.xml
        List<Element> mapperList = rootElement.selectNodes("//mapper");
        for (Element element : mapperList) {
            String mapperPath = element.attributeValue("resource");
            InputStream resourceAsStream = Resources.getResourceAsStream(mapperPath);
            XMLMapperBuilder xmlMapperBuilder = new XMLMapperBuilder(this.configuration);
            xmlMapperBuilder.parse(resourceAsStream);
        }


        return this.configuration;

//        使用数据库连接池的套路：
//        BasicDataSource dataSource = new BasicDataSource();
//        dataSource.setDriverClassName(driver);
//        dataSource.setUrl(url);
//        dataSource.setUsername(username);
//        dataSource.setPassword(password);
//        dataSource.setInitialSize(Integer.parseInt(initSize));//初始连接数量
//        dataSource.setMaxActive(Integer.parseInt(maxSize));//最大连接数量
//        Connection conn = dataSource.getConnection();
//        Statement stat = conn.createStatement();
//        String sql = "";
//        stat.execute(sql);
//        stat.close();
//        conn.close();

        //解析mapper.xml

    }
}

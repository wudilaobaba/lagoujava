package com.whj.sqlSession;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.whj.config.BoundSql;
import com.whj.pojo.Configuration;
import com.whj.pojo.MappedStatement;
import com.whj.utils.GenericTokenParser;
import com.whj.utils.ParameterMapping;
import com.whj.utils.ParameterMappingTokenHandler;
import com.whj.utils.TokenHandler;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 用来执行jdbc原生代码
 */
public class SimpleExecutor implements Executor{
    @Override
    public <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object... params) throws SQLException, ClassNotFoundException, NoSuchFieldException {
        Connection connection = configuration.getDataSource().getConnection();
        //select * from user where id = #{id} and username = #{username}
        String sql = mappedStatement.getSql();
        //转换sql语句：
        //select * from user where id = ? and username = ?
        BoundSql boundSql = this.getBoundSql(sql);
        PreparedStatement preparedStatement = connection.prepareStatement(boundSql.getSqlText());

        //设置参数
        String paramterType = mappedStatement.getParamterType();//参数的全路径
        Class<?> paramterClass =  getClasType(paramterType);
        List<ParameterMapping> parameterMappingList = boundSql.getParameterMappingList();
        for (int i = 0; i < parameterMappingList.size(); i++) {
            String content = parameterMappingList.get(i).getContent();
            //反射，根据content获取到实体对像的属性
            Field declaredField = paramterClass.getDeclaredField(content);

        }
        ResultSet rs = preparedStatement.executeQuery();
        List<E> eList = new ArrayList<>();
        while(rs.next()) {

            int id = rs.getInt("id");
            String name = rs.getString("name");
            System.out.println(id+":"+"name");
        }
        rs.close();
        preparedStatement.close();
        connection.close();
        return null;
    }

    private BoundSql getBoundSql(String sql){
        //标记处理类：解析占位符
        ParameterMappingTokenHandler parameterMappingTokenHandler = new ParameterMappingTokenHandler();
        GenericTokenParser genericTokenParser = new GenericTokenParser("#{","}",parameterMappingTokenHandler);
        //返回真实的jpql的sql语句
        String parseSql = genericTokenParser.parse(sql);
        //#{}中的参数名称 [{content:"username"},{content:"id"}]
        List<ParameterMapping> parameterMappings = parameterMappingTokenHandler.getParameterMappings();
        BoundSql boundSql = new BoundSql(parseSql,parameterMappings);
        return boundSql;
    }

    private Class<?> getClasType(String paramterType) throws ClassNotFoundException {
        if(paramterType!=null){
            Class<?> aClass = Class.forName(paramterType);
            return aClass;
        }
        return null;
    }
}

package com.whj.config;

import com.whj.utils.ParameterMapping;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BoundSql {
    private String sqlText;//真实sql
    private List<ParameterMapping> parameterMappingList = new ArrayList<>();

}

package com.whj.sqlSession;

public class DefaultSqlSession implements SqlSession{
}

package com.whj.utils;

public class ParameterMapping {

    private String content;//#{}这种sql解析数来的参数名

    public ParameterMapping(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

package com.whj.sqlSession;

public interface SqlSession {
}

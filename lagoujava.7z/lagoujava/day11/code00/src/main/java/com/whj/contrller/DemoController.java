package com.whj.contrller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping("/demo")//根
public class DemoController {
    /**
     * 第一种：
     * url: http://localhost:8080/demo/handle01
     */
    @RequestMapping("/handle01")
    public ModelAndView handle01(){
        Date date = new Date();// 服务器时间
        //返回服务器时间到前台页面
        //封装了数据和页面信息的模型 ModelAndView
        ModelAndView modelAndView = new ModelAndView();
        //addObject:像请求域中 request.serAttribute("date",date);
        modelAndView.addObject("date",date);
        //视图信息(封装跳转的页面信息) WEB-INF中新建一个jsp目录
        modelAndView.setViewName("success");//设置逻辑视图名 也就是/WEB-INF/jsp/success.jsp
        return modelAndView;
    }
    /**
     * SpringMVC在handler方法上传入Map、Model和ModelMap参数，并向这些参数中保存数据（放入到请求域），都可以在页面获取到
     *
     * 它们之间是什么关系？
     * 运行时的具体类型都是BindingAwareModelMap，相当于给BindingAwareModelMap中保存的数据都会放在请求域中
     *
     *  Map(jdk中的接口)
     *
     *  Model（spring的接口）
     *
     *  ModelMap(class,实现Map接口)
     *
     *
     *              后面三种中的参数类型最终都是：BindingAwareModelMap
     *
     *              BindingAwareModelMap继承了ExtendedModelMap，ExtendedModelMap继承了ModelMap,实现了Model接口
     *
     */

    /**
     * 第二种：
     * url: http://localhost:8080/demo/handle02
     */
    @RequestMapping("/handle02")
    public String handle02(ModelMap modelMap){
        Date date = new Date();// 服务器时间
        modelMap.addAttribute("date",date);
        System.out.println("============modelMap:"+modelMap.getClass());
        return "success";//将视图名返回
    }

    /**
     * 第三种：
     * url: http://localhost:8080/demo/handle03
     */
    @RequestMapping("/handle03")
    public String handle03(Model model){
        Date date = new Date();// 服务器时间
        model.addAttribute("date",date);
        System.out.println("============model:"+model.getClass());
        return "success";//将视图名返回
    }

    /**
     * 第四种：
     * url: http://localhost:8080/demo/handle04
     */
    @RequestMapping("/handle04")
    public String handle04(Map<String,Object> map){
        Date date = new Date();// 服务器时间
        map.put("date",date);
        System.out.println("============map:"+map.getClass());
        return "success";//将视图名返回
    }
}

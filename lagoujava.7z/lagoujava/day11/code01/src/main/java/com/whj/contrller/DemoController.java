package com.whj.contrller;

import com.whj.pojo.User;
import com.whj.pojo.UserInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping("/demo")//根
public class DemoController {
    /**
     * 第一种 接收get参数：
     * url: http://localhost:8080/demo/handle01?id=1
     */
    @RequestMapping("/handle01")
    public ModelAndView handle01(HttpServletRequest request, HttpServletResponse response, HttpSession session){
        String id = request.getParameter("id");//获取请求参数
        System.out.println(id);
        Date date = new Date();// 服务器时间
        //返回服务器时间到前台页面
        //封装了数据和页面信息的模型 ModelAndView
        ModelAndView modelAndView = new ModelAndView();
        //addObject:像请求域中 request.serAttribute("date",date);
        modelAndView.addObject("date",date);
        //视图信息(封装跳转的页面信息) WEB-INF中新建一个jsp目录
        modelAndView.setViewName("success");//设置逻辑视图名 也就是/WEB-INF/jsp/success.jsp
        return modelAndView;
    }

    /**
     * 第二种 接收get简单类型参数：
     * 简单数据类型参数，直接在handler方法的参数中直接声明即可，框架会取出参数值，绑定到参数上，传递的参数名和声明的形参名称保持一致
     * url: http://localhost:8080/demo/handle02?id=2
     */
    @RequestMapping("/handle02")
    public ModelAndView handle02(//参数建议使用包装类型，对于Boolean类型的参数，请求参数只能为1,0,true,false
            @RequestParam("ids") Integer id //参数可以直接写Integer id，加@RequestParam("ids")是为了与前端参数名一致
    ){
        System.out.println(id);
        Date date = new Date();// 服务器时间
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("date",date);
        modelAndView.setViewName("success");
        return modelAndView;
    }

    /**
     * 第三种 接收get的pojo类型参数：
     * 直接形参接收即可。框架会取出参数值，绑定到参数上，传递的参数名和声明的pojo中的字段名称保持一致
     * url: http://localhost:8080/demo/handle03?userName=zhangsan&id=456
     */
    @RequestMapping("/handle03")
    public ModelAndView handle03(//参数建议使用包装类型，对于Boolean类型的参数，请求参数只能为1,0,true,false
                                 User user //参数可以直接写Integer id，加@RequestParam("ids")是为了与前端参数名一致
    ){
        System.out.println(user);
        Date date = new Date();// 服务器时间
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("date",date);
        modelAndView.setViewName("success");
        return modelAndView;
    }

    /**
     * 第四种 接收get的pojo包装类型参数：
     * 直接形参接收即可。框架会取出参数值，绑定到参数上，传递的参数名和声明的pojo中的字段名称保持一致
     * url: http://localhost:8080/demo/handle04?user.userName=zhangsan&user.id=456
     * 不管包装Pojo与否，它首先是一个pojo，那么就可以按照上述pojo的要求来
     *     1、绑定时候直接形参声明即可
     *     2、传参参数名和pojo属性保持一致，如果不能够定位数据项，那么通过属性名 + "." 的方式进一步锁定数据
     */
    @RequestMapping("/handle04")
    public ModelAndView handle04(//参数建议使用包装类型，对于Boolean类型的参数，请求参数只能为1,0,true,false
                                 UserInfo userInfo //参数可以直接写Integer id，加@RequestParam("ids")是为了与前端参数名一致
    ){
        System.out.println(userInfo);
        Date date = new Date();// 服务器时间
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("date",date);
        modelAndView.setViewName("success");
        return modelAndView;
    }

    /**
     * 第五种 接收get的日期类型参数：
     * 首先要定义一个springMVC的类型转换器，实现接口即可，然后注册实现:com.whj.converter.DateConveter
     * 注册类型转换器：springmvc.xml中：自定义类型转换器,并关联到mvc:annotation-driven中
     * url: http://localhost:8080/demo/handle05?birthday=2020-09-05
     * 请求参数错误会报400
     */
    @RequestMapping("/handle05")
    public ModelAndView handle05(//参数建议使用包装类型，对于Boolean类型的参数，请求参数只能为1,0,true,false
                                 Date birthday //参数可以直接写Integer id，加@RequestParam("ids")是为了与前端参数名一致
    ){
        System.out.println(birthday);
        Date date = new Date();// 服务器时间
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("date",date);
        modelAndView.setViewName("success");
        return modelAndView;
    }
}

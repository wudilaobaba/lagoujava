package aop;

public class Dog extends Animal{
    public static void main(String[] args) {

    }
}

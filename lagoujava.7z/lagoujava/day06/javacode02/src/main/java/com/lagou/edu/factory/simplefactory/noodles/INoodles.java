package com.lagou.edu.factory.simplefactory.noodles;

public interface INoodles {
    void desc();
}

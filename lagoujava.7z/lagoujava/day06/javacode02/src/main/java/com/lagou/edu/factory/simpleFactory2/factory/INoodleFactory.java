package com.lagou.edu.factory.simpleFactory2.factory;

import com.lagou.edu.factory.simpleFactory2.noodles.INoodles;

public interface INoodleFactory {
    INoodles createINoodles();
}

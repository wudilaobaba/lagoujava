package com.lagou.edu.factory.simplefactory.noodles;

public class LanZhouNoodles implements INoodles{
    @Override
    public void desc() {
        System.out.println("兰州拉面");
    }
}

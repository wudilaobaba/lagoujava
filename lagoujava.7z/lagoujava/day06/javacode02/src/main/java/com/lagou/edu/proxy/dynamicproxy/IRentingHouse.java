package com.lagou.edu.proxy.dynamicproxy;

/**
 * jdk动态代理、cglib动态代理
 */
public interface IRentingHouse {
    void rentHouse();
    String say();
}

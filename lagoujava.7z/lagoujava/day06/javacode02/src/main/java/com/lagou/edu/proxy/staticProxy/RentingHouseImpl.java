package com.lagou.edu.proxy.staticProxy;

public class RentingHouseImpl implements IRentingHouse{
    @Override
    public void rentHouse() {
        System.out.println("我要租房子");
    }
}

package com.lagou.edu.proxy.staticProxy;

public interface IRentingHouse {
    void rentHouse();
}

package com.lagou.edu.proxy.dynamicproxyfactory;

public interface IRetingHouse {
    void rentHouse();
    String say();
}

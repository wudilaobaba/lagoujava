package com.lagou.edu.factory.simpleFactory2.noodles;

public class PaoNoodles implements INoodles{
    @Override
    public void desc() {
        System.out.println("泡麵真難吃");
    }
}

package com.lagou.edu.factory.simpleFactory2.noodles;

public interface INoodles {
    void desc();
}

package com.lagou.edu.factory.simpleFactory2.noodles;

public class LanZhouNoodles implements INoodles{
    @Override
    public void desc() {
        System.out.println("蘭州拉麵真好吃");
    }
}

package com.whj.mapper;

import com.whj.pojo.User;

import tk.mybatis.mapper.common.Mapper;


public interface UserMapper extends Mapper<User> {

}

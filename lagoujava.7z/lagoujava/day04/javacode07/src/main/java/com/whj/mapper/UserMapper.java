package com.whj.mapper;

import com.whj.pojo.Order;
import com.whj.pojo.User;

import java.util.List;

public interface UserMapper {
    List<User> getAllUsers();
}

package com.whj.pojo;

import lombok.*;

@Getter
@Setter
public class Order {
    private Integer id;
    private String ordertime;
    private Double total;
    private Integer uid;
}

package com.whj.proxy;

public interface Person {
    void doSomething();
}

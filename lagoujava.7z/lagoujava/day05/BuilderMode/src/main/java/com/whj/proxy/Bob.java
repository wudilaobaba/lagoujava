package com.whj.proxy;

public class Bob implements Person{
    @Override
    public void doSomething() {
        System.out.println("I'm Bob");
    }
}

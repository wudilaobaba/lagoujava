package com.whj.simpleFactory;

public class LxComputer extends Computer{
    @Override
    public void start() {
        System.out.println("联想电脑启动");
    }
}

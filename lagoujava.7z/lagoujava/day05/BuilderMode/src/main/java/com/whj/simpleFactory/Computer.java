package com.whj.simpleFactory;

public abstract class Computer {
    public abstract void start();
}
